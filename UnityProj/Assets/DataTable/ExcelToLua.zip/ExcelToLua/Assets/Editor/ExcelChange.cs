﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using System.IO;
using System.Text;

using NPOI;
using NPOI.HPSF;
using NPOI.HSSF;
using NPOI.HSSF.UserModel;
using NPOI.POIFS;
using NPOI.Util;
using NPOI.HSSF.Util;
using NPOI.HSSF.Extractor;
using NPOI.XSSF;
using NPOI.XSSF.Util;
using NPOI.XSSF.UserModel;

public class ExcelChange
{
    /*
    [MenuItem("测试/输出lua")]
    public static void GetExcel()
    {
        Debug.Log(Application.dataPath);
        // HSSFWorkbook workBook = new HSSFWorkbook(Application.dataPath)
        FileStream fs = File.Open(Application.dataPath + "/" + "skill.xls", FileMode.Open, FileAccess.ReadWrite);
        
    HSSFWorkbook    workBook = new HSSFWorkbook(fs);
        HSSFSheet sheet = workBook.GetSheetAt(0) as HSSFSheet;

        HSSFRow headerRow = sheet.GetRow(0) as HSSFRow;
        int cellCount = headerRow.LastCellNum;

        for (int i = headerRow.FirstCellNum; i < cellCount; i++)
        {
            var cell = headerRow.GetCell(i);
            Debug.Log(cell.StringCellValue);
            Debug.Log(string.IsNullOrEmpty(cell.StringCellValue));
        }
    }
    */
    [MenuItem("测试/测试输出")]
    public static void GetExcelTest()
    {
        FileStream fs = File.Open(Application.dataPath + "/" + "skill.xlsx", FileMode.Open, FileAccess.ReadWrite);
        XSSFWorkbook workbook = new XSSFWorkbook(fs);
        XSSFSheet dataTypeSheet = workbook.GetSheet("dataType") as XSSFSheet;
        XSSFRow dataheaderRow = dataTypeSheet.GetRow(0) as XSSFRow;
        Debug.Log(dataheaderRow.LastCellNum);
        for (int i = dataheaderRow.FirstCellNum; i < dataheaderRow.LastCellNum; i++)
        {
            var cell = dataheaderRow.GetCell(i);
            Debug.Log(cell.ToString());
            Debug.Log(string.IsNullOrEmpty(cell.ToString()));
        }

        XSSFSheet sheet = workbook.GetSheetAt(0) as XSSFSheet;
        XSSFRow headerRow = sheet.GetRow(0) as XSSFRow;
        int cellCount = headerRow.LastCellNum;
        for (int i = headerRow.FirstCellNum; i < cellCount; i++)
        {
            var cell = headerRow.GetCell(i);
            Debug.Log(cell.ToString());
            Debug.Log(string.IsNullOrEmpty(cell.ToString()));
        }
        fs.Close();
        fs.Dispose();
    }

    public static List<string> _dataTypeList = new List<string>();
    public static StringBuilder _outPutBuilder = new StringBuilder();

    [MenuItem("测试/转换excel为lua")]
    public static void ChangeExcelToLua()
    {
        _dataTypeList = new List<string>();
        FileStream fs = File.Open(Application.dataPath + "/" + "skill.xlsx", FileMode.Open, FileAccess.ReadWrite);
        XSSFWorkbook wb = new XSSFWorkbook(fs);
        XSSFSheet dataTypeSheet = wb.GetSheet("dataType") as XSSFSheet;
        XSSFRow dataTypeRow = dataTypeSheet.GetRow(0) as XSSFRow;
        for (int i = dataTypeRow.FirstCellNum; i < dataTypeRow.LastCellNum; i++)
        {
            var cell = dataTypeRow.GetCell(i);
            string cellInfo = cell.ToString();
            if (!string.IsNullOrEmpty(cellInfo))
            {
                _dataTypeList.Add(cellInfo);
            }
        }
        XSSFSheet sheet = wb.GetSheetAt(0) as XSSFSheet;
        XSSFFormulaEvaluator e = new XSSFFormulaEvaluator(wb);
        Debug.Log(sheet.LastRowNum);

        _outPutBuilder = new StringBuilder();
        _outPutBuilder.AppendLine("return{");
        for (int i = 1; i < sheet.LastRowNum; i++)
        {
            StringBuilder rowSb = new StringBuilder();
            XSSFRow dataRow = sheet.GetRow(i) as XSSFRow;
            for (int j = 0; j < _dataTypeList.Count; j++)
            {
                string cellInfo = string.Empty;
              
                var cell = dataRow.GetCell(j);
                cell = e.EvaluateInCell(cell);
                if (cell == null)
                {
                    if (_dataTypeList[j] == "1")
                    {
                        cellInfo = "[[]]";
                    }
                    else
                    {
                        Debug.Log("错误！");
                    }
                }
                else
                {
                    if (_dataTypeList[j] == "1")
                    {
                        cellInfo = string.Format("[[{0}]]", cell.ToString());
                    }
                    else
                    {
                        cellInfo = cell.ToString();
                    }
                }

                if (j == 0)
                {
                    // rowSb.Append(string.Format("['{0}'] = {", cellInfo));
                    rowSb.Append("['");
                    rowSb.Append(cellInfo);
                    rowSb.Append("'] = {");
                }
                rowSb.Append(cellInfo);
                if (j == _dataTypeList.Count - 1)
                {
                    rowSb.Append("}");
                }
                else
                {
                    rowSb.Append(",");
                }

            }
            if (i == sheet.LastRowNum - 1)
            {
                rowSb.Append(string.Empty);
            }
            else
            {
                rowSb.Append(",");
            }
            _outPutBuilder.AppendLine(rowSb.ToString());
        }
        _outPutBuilder.Append("}");
        fs.Close();
        fs.Dispose();

        string luaDataPath = Application.dataPath + "/" + "skill.lua";
        StreamWriter sw = new StreamWriter(luaDataPath, false, Encoding.UTF8);
        sw.WriteLine(_outPutBuilder.ToString());
        sw.Close();
        sw.Dispose();
    }
}
